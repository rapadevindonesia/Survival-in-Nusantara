# Survival in Nusantara

**Developer**: Rapa & Mentor AI  
Game survival fullscreen touchscreen dengan karakter Rapa & musuh Badawang.

## Cara Main
1. Buka `index.html` di browser HP atau PC  
2. Gunakan tombol layar: panah, 🗡️, 🍎, 🔥  
3. Arahkan Rapa untuk kumpulin apel dan lawan Badawang  
4. Dekat apinya? Blood & hunger regen

## Save & Load
- Progress otomatis disimpan tiap detik ke `localStorage`  
- Saat reload, data dipulihkan  
- Bisa reset dengan clear cache game

## Lanjut:
- Di versi v3.1: crafting bahan kayu, bangun rumah
- Bisa export ke APK atau GitHub Pages